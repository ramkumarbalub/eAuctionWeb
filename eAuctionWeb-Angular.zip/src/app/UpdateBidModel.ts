export interface UpdateBidModel{
    productId: string;
    emailId: string;
    bidPrice: string;
}