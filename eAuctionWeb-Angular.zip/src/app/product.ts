export interface Product{
        productId: string;
        productname: string;
        shortdescription: string;
        detaileddescription: string;
        category: string;
        startingprice: any;
        bidenddate: any;
}